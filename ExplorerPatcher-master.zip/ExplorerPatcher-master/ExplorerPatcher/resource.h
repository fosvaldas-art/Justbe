//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExplorerPatcher.rc
//
#define IDS_PRODUCTNAME                 102
#define IDS_INSTALL_SUCCESS_TEXT        109
#define IDS_INSTALL_ERROR_TEXT          110
#define IDS_UNINSTALL_SUCCESS_TEXT      111
#define IDS_UNINSTALL_ERROR_TEXT        112
#define IDS_OPERATION_NONE              113
#define IDR_REFRESHEDSTYLES_XBF         115
#define IDS_DRIVECATEGORY_HARDDISKDRIVES              40000
#define IDS_DRIVECATEGORY_REMOVABLESTORAGE            40001
#define IDS_DRIVECATEGORY_OTHER                       40002
#define IDS_DRIVECATEGORY_IMAGING                     40003
#define IDS_DRIVECATEGORY_PORTABLEMEDIA               40004
#define IDS_DRIVECATEGORY_PORTABLEMEDIADEVICE         40004
#define IDS_DRIVECATEGORY_PORTABLEDEVICE              40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
